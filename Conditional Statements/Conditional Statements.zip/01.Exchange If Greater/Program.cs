﻿/*
Problem 1. Exchange If Greater
• Write an if-statement that takes two double variables a and b and exchanges their values if the first one is greater than the second one. As a result print the values a and b, separated by a space.

Examples:


a      b       result

5      2       2 5 
3      4       3 4 
5.5    4.5     4.5 5.5 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exchange_If_Greater
{
    class Program
    {
        static void Main(string[] args)
        {
            double dblFirstNumber;
            double dblSecondNumber;
            double dblBuffer;

            Console.Write("Please , enter the first number : ");
            dblFirstNumber=double.Parse(Console.ReadLine());
            Console.Write("Please , enter the second number : ");
            dblSecondNumber = double.Parse(Console.ReadLine());

            if(dblFirstNumber<dblSecondNumber)
            {
                dblBuffer=dblFirstNumber;
                dblFirstNumber=dblSecondNumber;
                dblSecondNumber=dblBuffer;
            }

            Console.WriteLine("The result is : {0} {1}",dblFirstNumber,dblSecondNumber);
        }
    }
}

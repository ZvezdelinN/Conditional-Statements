﻿/*
Problem 2. Bonus Score
• Write a program that applies bonus score to given score in the range  [1…9]  by the following rules: ◦ If the score is between  1  and  3 , the program multiplies it by  10 .
◦ If the score is between  4  and  6 , the program multiplies it by  100 .
◦ If the score is between  7  and  9 , the program multiplies it by  1000 .
◦ If the score is  0  or more than  9 , the program prints  “invalid score” .


Examples:


score              result
 
2                    20 
4                   400 
9                  9000 
-1        invalid score 
10        invalid score 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bonus_Score
{
    class Program
    {
        static void Main(string[] args)
        {
            int intScore;
            Console.Write("Please enter a number : ");
            intScore=int.Parse(Console.ReadLine());

            switch (intScore)
            {
                case 1:
                case 2:
                case 3:
                    intScore *= 10;
                    Console.WriteLine(intScore);
                    break;
                case 4:
                case 5:
                case 6:
                    intScore *= 100;
                    Console.WriteLine(intScore);
                    break;
                case 7:
                case 8:
                case 9:
                    intScore *= 1000;
                    Console.WriteLine(intScore);
                    break;
                default:
                    Console.WriteLine("Invalid score");
                    break;
            }

        }
    }
}

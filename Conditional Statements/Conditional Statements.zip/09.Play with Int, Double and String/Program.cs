﻿/*
 Problem 9. Play with Int, Double and String
• Write a program that, depending on the user’s choice, inputs an  int ,  double  or  string  variable. 
◦ If the variable is  int  or  double , the program increases it by one.
◦ If the variable is a  string , the program appends  *  at the end.

• Print the result at the console. Use switch statement.

Example 1:


program                     user


Please choose a type:  
1 --> int  
2 --> double  
3 --> string                  3 
Please enter a string:    hello   
hello*  

Example 2:


program                    user

Please choose a type:  
1 --> int  
2 --> double                  2 
3 --> string  
Please enter a double:        1.5 
2.5 
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Play_with_Int__Double_and_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string strString = "";
            double dblStringNumber;
            Console.Write("Please enter a number or string : ");
            strString = Console.ReadLine();

            try
            {
                dblStringNumber = double.Parse(strString);
                dblStringNumber += 1;
                Console.WriteLine(dblStringNumber);
            }
            catch 
            {
                Console.WriteLine(strString + " *");
            }
        }
    }
}
